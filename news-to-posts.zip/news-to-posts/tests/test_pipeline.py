"""Tests for the news-to-posts pipeline.

Run with:  python -m pytest -q     (or: python tests/test_pipeline.py)
No network access is required - every test uses bundled fixtures.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from newstoposts import posts, summarize  # noqa: E402
from newstoposts.config import Config  # noqa: E402
from newstoposts.extract import extract_article  # noqa: E402
from newstoposts.fetch import parse_date_string, set_transport  # noqa: E402

FIXTURES = ROOT / "fixtures"
BRAND = {"audience": "investors in India", "hashtags": ["#Markets", "#Investing"]}


def _article_html(name: str = "article_bloomberg.html") -> str:
    return (FIXTURES / name).read_text(encoding="utf-8")


def _item(name: str = "article_bloomberg.html", title: str = "") -> dict:
    article = extract_article(_article_html(name), "https://example.com/story")
    text = article["body"]
    return {
        "title": title or "Global Funds Turn Net Buyers of Indian Equities",
        "url": "https://example.com/story",
        "source_name": "Bloomberg",
        "body": text,
        "body_chars": len(text),
        "text": text,
        "sentences": summarize.summarize(text, title, max_sentences=18),
        "keywords": summarize.key_phrases(text, title, limit=6),
        "facts": summarize.key_facts(text, title, limit=4),
        "thin": len(text) < 700,
        "paywalled": article["paywalled"],
        "published": None,
    }


# --------------------------------------------------------------------------- #
# extraction
# --------------------------------------------------------------------------- #
def test_extracts_article_body():
    article = extract_article(_article_html(), "https://example.com/story")
    assert article["body_chars"] > 2000
    assert "Indian stocks" in article["body"]
    # nav and footer boilerplate must not leak into the body
    assert "Subscribe to continue reading" not in article["body"]
    assert article["paywalled"] is False


def test_flags_thin_paywalled_page():
    article = extract_article(_article_html("article_short.html"), "https://example.com/x")
    assert article["body_chars"] < 700
    assert article["paywalled"] is True


# --------------------------------------------------------------------------- #
# summarisation
# --------------------------------------------------------------------------- #
def test_summary_respects_length_and_order():
    text = extract_article(_article_html(), "")["body"]
    sentences = summarize.summarize(text, "Test title", max_sentences=5)
    assert 0 < len(sentences) <= 5
    # sentences come back in reading order
    positions = [text.find(s) for s in sentences]
    assert positions == sorted(positions)


def test_similar_catches_rewordings():
    a = "Overseas investors bought a net $1.8 billion of Indian stocks last week."
    b = "Overseas investors bought a net $1.8 billion of Indian stocks in the week to Friday."
    c = "Gold traded within 1.2% of its all-time high on Tuesday."
    assert summarize.similar(a, b)
    assert not summarize.similar(a, c)


def test_key_facts_contain_numbers():
    text = extract_article(_article_html(), "")["body"]
    facts = summarize.key_facts(text, "", limit=3)
    assert facts
    assert all(re.search(r"\d", fact) for fact in facts)


def test_key_phrases_are_multi_word_topics():
    text = extract_article(_article_html(), "")["body"]
    phrases = summarize.key_phrases(text, "", limit=4)
    assert phrases
    for phrase in phrases:
        assert len(phrase.split()) == 2
        assert not re.search(r"\d", phrase)


# --------------------------------------------------------------------------- #
# drafts
# --------------------------------------------------------------------------- #
def test_linkedin_within_word_band():
    draft = posts.build_linkedin(_item(), BRAND)
    assert 150 <= draft["words"] <= 250, draft["words"]
    assert draft["text"].startswith("Global Funds Turn Net Buyers")


def test_x_thread_limits_and_count():
    draft = posts.build_x_thread(_item(), BRAND)
    assert 5 <= draft["count"] <= 7
    for tweet in draft["tweets"]:
        assert len(tweet) <= posts.X_LIMIT, (len(tweet), tweet)
    assert draft["tweets"][-1].startswith("Source:") or "Source:" in draft["tweets"][-1]


def test_blog_in_word_band():
    draft = posts.build_blog(_item(), BRAND)
    assert 600 <= draft["words"] <= 900, draft["words"]
    assert "## What to watch" in draft["text"]
    assert "https://example.com/story" in draft["text"]


def test_no_duplicate_sentences_across_draft():
    item = _item()
    draft = posts.build_blog(item, BRAND)
    body = draft["text"]
    sentences = [s for s in summarize.split_sentences(body) if len(s) > 60]
    seen: list[str] = []
    for sentence in sentences:
        assert not any(summarize.similar(sentence, kept) for kept in seen), sentence
        seen.append(sentence)


def test_thin_source_is_flagged():
    item = _item("article_short.html", title="Gold Holds Near Record")
    draft = posts.build_blog(item, BRAND)
    assert any("thin" in warning or "short" in warning for warning in draft["warnings"])


def test_empty_source_produces_no_draft():
    item = _item()
    item["sentences"] = []
    item["text"] = ""
    draft = posts.build_linkedin(item, BRAND)
    assert draft["text"] == ""
    assert draft["warnings"]


# --------------------------------------------------------------------------- #
# plumbing
# --------------------------------------------------------------------------- #
def test_date_parsing_variants():
    assert parse_date_string("November 17, 2026").year == 2026
    assert parse_date_string("17 November 2026").month == 11
    assert parse_date_string("2026-11-17T04:20:00Z").day == 17
    assert parse_date_string("17-Nov-2026").day == 17
    assert parse_date_string("no date here") is None


def test_config_loads_sources():
    config = Config.load(ROOT / "config")
    assert len(config.sources) >= 4
    assert all(source["id"] and source["type"] for source in config.sources)
    assert "linkedin" in config.enabled_formats()


def test_digest_recipient_configured():
    config = Config.load(ROOT / "config")
    recipient = config.get("email", "to")
    assert recipient and "@" in recipient


def test_slugify():
    assert posts.slugify("Gold Holds Near Record!") == "gold-holds-near-record"
    assert posts.slugify("") == "story"


if __name__ == "__main__":
    failures = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"PASS {name}")
            except AssertionError as exc:
                failures += 1
                print(f"FAIL {name}: {exc}")
    print(f"\n{'all passed' if not failures else str(failures) + ' failed'}")
    sys.exit(1 if failures else 0)
