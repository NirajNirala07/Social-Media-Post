#!/usr/bin/env python3
"""Entry point for the daily run.

    python run.py                 # live run, writes drafts + emails the digest
    python run.py --demo          # full pipeline on bundled sample data
    python run.py --demo --no-email --limit 1
"""

from __future__ import annotations

import argparse
import logging
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

from newstoposts import digest, posts, state
from newstoposts.config import Config, env
from newstoposts.extract import fetch_body
from newstoposts.fetch import collect, set_transport, within_age
from newstoposts.summarize import clean, key_facts, key_phrases, summarize

log = logging.getLogger("news-to-posts")

ROOT = Path(__file__).resolve().parent
DEMO_DIR = ROOT / "fixtures"


# --------------------------------------------------------------------------- #
# demo transport: serve fixtures instead of the network
# --------------------------------------------------------------------------- #
def demo_transport(url: str, timeout: int = 25):
    if url.rstrip("/").endswith("robots.txt"):
        return "User-agent: *\nAllow: /\n"
    if "feeds.bloomberg.com/news.rss" in url:
        return (DEMO_DIR / "bloomberg_news.xml").read_text(encoding="utf-8")
    if "markets/news.rss" in url:
        return (DEMO_DIR / "bloomberg_markets.xml").read_text(encoding="utf-8")
    if "economics/news.rss" in url:
        return (DEMO_DIR / "bloomberg_economics.xml").read_text(encoding="utf-8")
    if "news.google.com/rss/search" in url:
        return (DEMO_DIR / "google_news.xml").read_text(encoding="utf-8")
    if "sample-india-record-highs" in url:
        return (DEMO_DIR / "article_bloomberg.html").read_text(encoding="utf-8")
    if "india-equities" in url:
        return (DEMO_DIR / "article_bloomberg.html").read_text(encoding="utf-8")
    if "em-debt" in url:
        return (DEMO_DIR / "article_em_debt.html").read_text(encoding="utf-8")
    if "morganstanley.com/insights" in url:
        return (DEMO_DIR / "ms_insights.html").read_text(encoding="utf-8")
    if "about-us-newsroom" in url:
        return (DEMO_DIR / "ms_newsroom.html").read_text(encoding="utf-8")
    if "bloomberg.com" in url:
        return (DEMO_DIR / "article_short.html").read_text(encoding="utf-8")
    return (DEMO_DIR / "article_morganstanley.html").read_text(encoding="utf-8")


# --------------------------------------------------------------------------- #
# pipeline
# --------------------------------------------------------------------------- #
def analyse(item: Dict[str, Any], config: Config) -> Dict[str, Any]:
    """Fetch the body if needed, then derive every field the writers use."""
    timeout = int(config.get("run", "request_timeout", 25))
    body = item.get("body") or ""

    if item.get("fetch_body") and not body:
        article = fetch_body(item["url"], timeout)
        if article:
            body = article.get("body") or ""
            item["paywalled"] = article.get("paywalled", False)
            if not item.get("summary"):
                item["summary"] = article.get("description", "")
            if not item.get("published") and article.get("published"):
                from newstoposts.fetch import parse_date_string

                item["published"] = parse_date_string(article["published"])

    text = clean(" ".join(part for part in (item.get("summary"), body) if part))
    item["body"] = body
    item["text"] = text
    item["body_chars"] = len(body)
    item["sentences"] = summarize(text, item.get("title", ""), max_sentences=18)
    item["keywords"] = key_phrases(text, item.get("title", ""), limit=6)
    item["facts"] = key_facts(text, item.get("title", ""), limit=4)
    min_chars = int(config.get("run", "min_body_chars", 700))
    item["thin"] = item["body_chars"] < min_chars

    score = float(item.get("weight", 1.0))
    score *= 1.0 + 0.25 * len(item["facts"])
    score *= 1.0 + min(len(item["sentences"]), 12) / 24.0
    published = item.get("published")
    if published is not None:
        hours_old = (datetime.now(timezone.utc) - published).total_seconds() / 3600
        score *= max(0.4, 1.0 - min(hours_old, 48) / 96.0)
    if item["thin"]:
        score *= 0.7
    item["score"] = round(score, 3)
    return item


def run(args: argparse.Namespace) -> int:
    config = Config.load(args.config)
    out_root = Path(args.out or config.get("output", "dir", "output"))
    run_date = datetime.now().strftime("%Y-%m-%d")
    run_dir = out_root / run_date

    if args.demo:
        set_transport(demo_transport)
        log.info("demo mode: serving bundled fixtures, no network calls")

    store = state.State(args.state or "data/seen.json")

    # 1. collect
    candidates: List[Dict[str, Any]] = []
    max_age = float(config.get("run", "max_age_hours", 30))
    for source in config.sources:
        try:
            found = collect(source, int(config.get("run", "request_timeout", 25)))
        except Exception as exc:
            log.error("source %s failed: %s", source["id"], exc)
            continue
        kept = 0
        for item in found:
            if not within_age(item.get("published"), max_age):
                continue
            if store.has_seen(item["url"]) and not args.ignore_state:
                continue
            item["fetch_body"] = bool(source.get("fetch_body"))
            candidates.append(item)
            kept += 1
            if kept >= int(source.get("max_items", 10)):
                break

    if not candidates:
        log.info("nothing new today")
        if config.get("email", "skip_if_empty", True):
            return 0

    # 2. analyse + rank
    enriched = [analyse(item, config) for item in candidates]
    enriched.sort(key=lambda i: i["score"], reverse=True)
    limit = args.limit or int(config.get("run", "posts_per_day", 3))
    chosen = enriched[:limit]

    # 3. draft
    formats = args.formats or config.enabled_formats()
    brand = config.settings.get("brand", {})
    for item in chosen:
        drafts: Dict[str, Any] = {}
        if "linkedin" in formats:
            drafts["linkedin"] = posts.build_linkedin(item, brand)
        if "x_thread" in formats:
            drafts["x_thread"] = posts.build_x_thread(item, brand)
        if "blog" in formats:
            drafts["blog"] = posts.build_blog(item, brand)
        item["drafts"] = drafts

    # 4. write
    run_dir.mkdir(parents=True, exist_ok=True)
    for index, item in enumerate(chosen, start=1):
        stem = f"{index:02d}-{posts.slugify(item.get('title', 'story'))}"
        for fmt, draft in item["drafts"].items():
            if not (draft.get("text") or draft.get("tweets")):
                continue
            folder = run_dir / fmt
            folder.mkdir(exist_ok=True)
            path = folder / f"{stem}.md"
            path.write_text(posts.to_markdown(item, draft), encoding="utf-8")

    date_label = datetime.now().strftime("%d %B %Y")
    html_body = digest.build_html(chosen, date_label)
    md_body = digest.build_markdown(chosen, date_label)
    (run_dir / "digest.html").write_text(html_body, encoding="utf-8")
    md_path = run_dir / "digest.md"
    md_path.write_text(md_body, encoding="utf-8")

    log.info("wrote %d stories to %s", len(chosen), run_dir)
    for item in chosen:
        flags = sum(len(d.get("warnings") or []) for d in item["drafts"].values())
        log.info(
            "  %-55s score=%.2f body=%d%s",
            item.get("title", "")[:55],
            item["score"],
            item["body_chars"],
            f" flags={flags}" if flags else "",
        )

    # 5. email
    if args.no_email or not config.get("email", "enabled", True):
        log.info("email disabled for this run")
    else:
        prefix = config.get("email", "subject_prefix", "[Daily Brief]")
        subject = f"{prefix} {date_label} - {len(chosen)} stor{'y' if len(chosen)==1 else 'ies'}"
        digest.send_email(
            subject,
            html_body,
            md_body,
            attachments=[md_path],
            to_address=config.get("email", "to"),
        )

    # 6. remember
    store.mark(item["url"] for item in chosen)
    store.prune()
    if not args.demo:
        store.save()
    else:
        log.info("demo mode: state not saved")

    _prune_runs(out_root, int(config.get("output", "keep_days", 60)))
    return 0


def _prune_runs(out_root: Path, keep_days: int) -> None:
    if not out_root.exists() or keep_days <= 0:
        return
    cutoff = datetime.now().timestamp() - keep_days * 86400
    for child in out_root.iterdir():
        if child.is_dir() and child.stat().st_mtime < cutoff:
            shutil.rmtree(child, ignore_errors=True)
            log.info("pruned old run folder %s", child.name)


def main(argv: List[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Turn finance sites into ready-to-publish drafts.")
    parser.add_argument("--config", default=str(ROOT / "config"), help="config directory")
    parser.add_argument("--out", default=None, help="output directory (default: from settings)")
    parser.add_argument("--state", default=None, help="path to seen-URL store")
    parser.add_argument("--limit", type=int, default=None, help="how many stories to draft")
    parser.add_argument("--formats", nargs="*", default=None,
                        choices=["linkedin", "x_thread", "blog"], help="subset of formats")
    parser.add_argument("--demo", action="store_true", help="run on bundled fixtures, no network")
    parser.add_argument("--no-email", action="store_true", help="write files, skip the email")
    parser.add_argument("--ignore-state", action="store_true", help="re-draft stories seen before")
    parser.add_argument("--verbose", "-v", action="store_true")
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(levelname)-7s %(message)s",
        datefmt="%H:%M:%S",
    )
    return run(args)


if __name__ == "__main__":
    sys.exit(main())
