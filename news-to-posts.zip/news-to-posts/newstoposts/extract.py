"""Article body extraction: JSON-LD first, then a readability-style heuristic."""

from __future__ import annotations

import json
import logging
import re
from typing import Any, Dict, Optional, Tuple

from bs4 import BeautifulSoup

log = logging.getLogger(__name__)

_META_KEYS = {
    "description": ["description", "og:description", "twitter:description"],
    "title": ["og:title", "twitter:title"],
    "published": [
        "article:published_time",
        "datePublished",
        "publish-date",
        "parsely-pub-date",
    ],
    "author": ["author", "article:author"],
}


def _meta(soup: BeautifulSoup, names) -> str:
    for name in names:
        tag = soup.find("meta", attrs={"property": name}) or soup.find(
            "meta", attrs={"name": name}
        )
        if tag and tag.get("content"):
            return tag["content"].strip()
    return ""


def _json_ld_article(soup: BeautifulSoup) -> Tuple[str, Dict[str, str]]:
    """Pull articleBody/headline/datePublished out of schema.org JSON-LD."""
    body, meta = "", {}
    for script in soup.find_all("script", attrs={"type": "application/ld+json"}):
        raw = script.string or script.get_text() or ""
        raw = raw.strip()
        if not raw:
            continue
        try:
            data = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            continue
        nodes = []
        if isinstance(data, list):
            nodes = data
        elif isinstance(data, dict):
            nodes = data.get("@graph", [data])
        for node in nodes:
            if not isinstance(node, dict):
                continue
            if not body and isinstance(node.get("articleBody"), str):
                body = node["articleBody"]
            for key, target in (
                ("headline", "title"),
                ("datePublished", "published"),
            ):
                if target not in meta and isinstance(node.get(key), str):
                    meta[target] = node[key]
    return body, meta


def _link_density(node) -> float:
    text_len = len(node.get_text(" ", strip=True))
    if text_len == 0:
        return 1.0
    link_len = sum(len(a.get_text(" ", strip=True)) for a in node.find_all("a"))
    return link_len / text_len


def _candidate_paragraphs(soup: BeautifulSoup) -> str:
    for junk in soup.find_all(["script", "style", "noscript", "nav", "footer", "header", "aside", "form"]):
        junk.decompose()

    candidates = []
    for tag in soup.find_all(["article", "main", "div", "section"]):
        paragraphs = tag.find_all("p", recursive=True)
        if len(paragraphs) < 2:
            continue
        text_len = sum(len(p.get_text(" ", strip=True)) for p in paragraphs)
        if text_len < 200:
            continue
        density = _link_density(tag)
        if density > 0.4:
            continue
        # Prefer containers with many long paragraphs.
        score = text_len * (1.0 - density) * min(len(paragraphs), 20) ** 0.4
        candidates.append((score, tag))

    if candidates:
        candidates.sort(key=lambda pair: pair[0], reverse=True)
        best = candidates[0][1]
        paragraphs = [
            re.sub(r"\s+", " ", p.get_text(" ", strip=True)).strip()
            for p in best.find_all("p", recursive=True)
        ]
    else:
        paragraphs = [
            re.sub(r"\s+", " ", p.get_text(" ", strip=True)).strip()
            for p in soup.find_all("p")
        ]

    keep = []
    for para in paragraphs:
        if len(para) < 45:
            continue
        if para.lower().startswith(("cookie", "we use cookies", "subscribe", "sign up")):
            continue
        keep.append(para)
    return "\n\n".join(keep)


def extract_article(html: str, url: str = "") -> Dict[str, Any]:
    soup = BeautifulSoup(html, "html.parser")
    json_body, json_meta = _json_ld_article(soup)

    meta = {
        "description": _meta(soup, _META_KEYS["description"]),
        "title": _meta(soup, _META_KEYS["title"]) or json_meta.get("title", ""),
        "published": _meta(soup, _META_KEYS["published"]) or json_meta.get("published", ""),
        "author": _meta(soup, _META_KEYS["author"]),
    }
    if not meta["title"] and soup.title:
        meta["title"] = soup.title.get_text(" ", strip=True)

    body = re.sub(r"\s+", " ", json_body).strip() if json_body else ""
    if len(body) < 400:
        body = _candidate_paragraphs(soup)

    return {
        "url": url,
        "title": meta["title"],
        "description": meta["description"],
        "published": meta["published"],
        "author": meta["author"],
        "body": body,
        "body_chars": len(body),
        "paywalled": _looks_paywalled(soup, body),
    }


def _looks_paywalled(soup: BeautifulSoup, body: str) -> bool:
    if len(body) >= 1200:
        return False
    text = soup.get_text(" ", strip=True).lower()
    markers = (
        "subscribe to continue",
        "already a subscriber",
        "sign in to continue",
        "this article is for subscribers",
        "to continue reading",
        "unlock this article",
    )
    return any(marker in text for marker in markers)


def fetch_body(url: str, timeout: int = 25) -> Optional[Dict[str, Any]]:
    from . import fetch as fetch_mod

    if not fetch_mod.allowed_by_robots(url, timeout):
        log.info("robots.txt disallows %s - using feed summary only", url)
        return None
    html = fetch_mod.http_get(url, timeout)
    if not html:
        return None
    try:
        return extract_article(html, url)
    except Exception as exc:  # pragma: no cover - defensive
        log.warning("article extraction failed for %s: %s", url, exc)
        return None
