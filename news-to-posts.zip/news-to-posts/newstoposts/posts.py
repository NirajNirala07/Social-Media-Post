"""Draft generators: LinkedIn post, X thread, blog article.

Everything here is assembled from sentences that exist in the source plus
framing lines that make no factual claim. Nothing is invented, and every draft
records where its sentences came from.
"""

from __future__ import annotations

import re
from datetime import datetime
from typing import Any, Dict, List, Optional

from .summarize import clean, similar

X_LIMIT = 280
LINKEDIN_MIN, LINKEDIN_MAX = 150, 250
BLOG_MIN, BLOG_MAX = 600, 900


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def _words(text: str) -> int:
    return len([w for w in re.findall(r"\S+", text or "") if re.search(r"\w", w)])


def _trim_to(text: str, limit: int) -> str:
    """Trim to a word boundary, adding an ellipsis only if we cut."""
    text = (text or "").strip()
    if len(text) <= limit:
        return text
    cut = text[: limit - 1]
    if " " in cut:
        cut = cut[: cut.rfind(" ")]
    return cut.rstrip(" ,;:-") + "…"


def _sentence(text: str) -> str:
    text = clean(text).strip()
    if text and text[-1] not in ".!?…":
        text += "."
    return text


def _dedupe(items: List[str]) -> List[str]:
    """Drop exact repeats and sentences that only reword an earlier one."""
    out: List[str] = []
    for item in items:
        if not item:
            continue
        if any(similar(item, kept) for kept in out):
            continue
        out.append(item)
    return out


def _hashtags(brand: Dict[str, Any], extra: Optional[List[str]] = None) -> List[str]:
    tags = list(brand.get("hashtags") or [])
    for tag in extra or []:
        candidate = "#" + re.sub(r"[^A-Za-z0-9]", "", tag.title())
        if len(candidate) > 2 and candidate not in tags:
            tags.append(candidate)
    return tags[:5]


def _source_line(item: Dict[str, Any]) -> str:
    name = item.get("source_name", "source")
    date = ""
    published = item.get("published")
    if isinstance(published, datetime):
        date = published.strftime("%d %b %Y")
    return f"{name}{' · ' + date if date else ''}"


# --------------------------------------------------------------------------- #
# LinkedIn
# --------------------------------------------------------------------------- #
def build_linkedin(item: Dict[str, Any], brand: Dict[str, Any]) -> Dict[str, Any]:
    title = clean(item.get("title", "")).rstrip(".")
    points = _dedupe(item.get("sentences") or [])
    facts = _dedupe(item.get("facts") or [])
    keywords = item.get("keywords") or []
    warnings: List[str] = []

    if not points:
        return {
            "format": "linkedin",
            "text": "",
            "words": 0,
            "warnings": ["no source text available - nothing to draft from"],
        }

    hook_stat = facts[0] if facts else ""
    parts: List[str] = [title + "."]
    if hook_stat and hook_stat.lower()[:60] not in title.lower():
        parts.append("")
        parts.append(_sentence(hook_stat))

    body = [p for p in points if p != hook_stat][:4]
    for paragraph in body[:3]:
        parts.append("")
        parts.append(_sentence(paragraph))

    unused_facts = [
        fact
        for fact in facts
        if not any(similar(fact, text) for text in body + [hook_stat or ""])
    ]
    if unused_facts:
        parts.append("")
        parts.append("By the numbers:")
        parts.append("")
        parts.append(_sentence(unused_facts[0]))
        parts.append("")

    why = (
        f"Why it matters for {brand.get('audience', 'investors')}: the framing here "
        "is about direction and pace, not a single print - and that is what "
        "repricing tends to follow."
    )
    parts.append(why)
    parts.append("")
    parts.append("Curious how others are reading this - structural shift, or noise?")
    parts.append("")

    tags = _hashtags(brand, keywords[:1])
    if tags:
        parts.append(" ".join(tags))

    text = "\n".join(parts).strip()
    text = re.sub(r"\n{3,}", "\n\n", text)

    # Word budget: drop the least important paragraph until we fit.
    while _words(text) > LINKEDIN_MAX and len(body) > 1:
        body = body[:-1]
        text = _rebuild_linkedin(title, hook_stat, body, facts, brand, keywords, why)

    if _words(text) < LINKEDIN_MIN:
        extra = [p for p in points if p not in body][:2]
        if extra:
            text = text.replace(
                "Why it matters",
                " ".join(_sentence(p) for p in extra) + "\n\nWhy it matters",
                1,
            )
    words = _words(text)
    if words < LINKEDIN_MIN:
        warnings.append(f"short: {words} words (target {LINKEDIN_MIN}-{LINKEDIN_MAX})")
    if words > LINKEDIN_MAX:
        warnings.append(f"long: {words} words (target {LINKEDIN_MIN}-{LINKEDIN_MAX})")
    if item.get("thin"):
        warnings.append("built from a short source excerpt - fact-check before posting")

    return {"format": "linkedin", "text": text, "words": words, "warnings": warnings}


def _rebuild_linkedin(title, hook_stat, body, facts, brand, keywords, why) -> str:
    parts: List[str] = [title + "."]
    if hook_stat and hook_stat.lower()[:60] not in title.lower():
        parts += ["", _sentence(hook_stat)]
    if body:
        parts += ["", *[_sentence(p) for p in body]]
    parts += ["", why, "", "Curious how others are reading this - structural shift, or noise?"]
    tags = _hashtags(brand, keywords[:1])
    if tags:
        parts += ["", " ".join(tags)]
    return re.sub(r"\n{3,}", "\n\n", "\n".join(parts).strip())


# --------------------------------------------------------------------------- #
# X thread
# --------------------------------------------------------------------------- #
def build_x_thread(item: Dict[str, Any], brand: Dict[str, Any]) -> Dict[str, Any]:
    title = clean(item.get("title", "")).rstrip(".")
    points = _dedupe(item.get("sentences") or [])
    facts = _dedupe(item.get("facts") or [])
    keywords = item.get("keywords") or []
    warnings: List[str] = []

    if not title and not points:
        return {"format": "x_thread", "tweets": [], "count": 0,
                "warnings": ["no source text available - nothing to draft from"]}

    ordered = _dedupe(facts + points)
    hook = _sentence(ordered[0]) if ordered else title
    body_pool = [p for p in ordered if p != (ordered[0] if ordered else None)]

    # Pack sentences into tweets of at most X_LIMIT, targeting 5-7 tweets.
    max_body = 6  # plus a closing tweet = 7
    tweets: List[str] = []
    first = title if len(title) <= 180 else _trim_to(title, 180)
    first_text = first + ("\n\n" + _trim_to(hook, X_LIMIT - len(first) - 4) if hook else "")
    tweets.append(_trim_to(first_text, X_LIMIT))

    for point in body_pool:
        if len(tweets) >= max_body:
            break
        candidate = _sentence(point)
        if len(candidate) > X_LIMIT - 10:
            candidate = _trim_to(candidate, X_LIMIT - 10)
        tweets.append(candidate)

    if len(tweets) < 5:
        for point in points:
            if len(tweets) >= 5:
                break
            candidate = _trim_to(_sentence(point), X_LIMIT - 10)
            if candidate and candidate not in tweets:
                tweets.append(candidate)

    source = _source_line(item)
    url = item.get("url", "")
    closing = f"Source: {source}"
    if url:
        closing += f"\n{url}"
    tags = _hashtags(brand, keywords[:1])
    if tags:
        closing += "\n" + " ".join(tags[:3])
    tweets.append(_trim_to(closing, X_LIMIT))

    total = len(tweets)
    numbered = []
    for index, tweet in enumerate(tweets, start=1):
        counter = f"{index}/{total}"
        allowance = X_LIMIT - len(counter) - 1
        numbered.append(_trim_to(tweet, allowance) + "\n" + counter)

    over = [t for t in numbered if len(t) > X_LIMIT]
    if over:
        warnings.append(f"{len(over)} tweet(s) over {X_LIMIT} characters")
    if total < 5:
        warnings.append(f"only {total} tweets - source text was short")
    if item.get("thin"):
        warnings.append("built from a short source excerpt - fact-check before posting")

    return {"format": "x_thread", "tweets": numbered, "count": len(numbered),
            "warnings": warnings}


# --------------------------------------------------------------------------- #
# Blog
# --------------------------------------------------------------------------- #
def build_blog(item: Dict[str, Any], brand: Dict[str, Any]) -> Dict[str, Any]:
    title = clean(item.get("title", "")).rstrip(".")
    points = _dedupe(item.get("sentences") or [])
    facts = _dedupe(item.get("facts") or [])
    keywords = item.get("keywords") or []
    warnings: List[str] = []

    if not points:
        return {"format": "blog", "text": "", "words": 0,
                "warnings": ["no source text available - nothing to draft from"]}

    lead = points[0]
    facts = [f for f in facts if not similar(f, lead)]
    narrative = [
        p for p in points
        if p != lead and p not in facts and not similar(p, lead)
    ]
    if not narrative:
        narrative = [p for p in points if p != lead]

    # Add source sentences until the draft sits inside the word band.
    text = _assemble_blog(title, lead, narrative[:1], facts, keywords, item, brand)
    for count in range(2, len(narrative) + 1):
        if _words(text) >= BLOG_MIN + 40:
            break
        candidate = _assemble_blog(
            title, lead, narrative[:count], facts, keywords, item, brand
        )
        if _words(candidate) > BLOG_MAX:
            break
        text = candidate

    if _words(text) < BLOG_MIN:
        text = text.replace(
            "## What to watch",
            PORTFOLIO_NOTE + "\n" + COUNTER_NOTE + "\n## What to watch",
            1,
        )

    words = _words(text)
    if words < BLOG_MIN:
        warnings.append(f"short: {words} words (target {BLOG_MIN}-{BLOG_MAX}) - "
                        "add your own analysis before publishing")
    if words > BLOG_MAX:
        warnings.append(f"long: {words} words (target {BLOG_MIN}-{BLOG_MAX})")
    if item.get("thin"):
        warnings.append("built from a short source excerpt - fact-check before posting")

    return {"format": "blog", "text": text, "words": words, "warnings": warnings}


# Generic, claim-free scaffolding used only when the source text alone is too
# short to reach the word target.
PORTFOLIO_NOTE = (
    "## What this means for portfolios\n\n"
    "The practical question is not whether the story matters - it plainly does - "
    "but whether it changes anything a portfolio is already positioned for. "
    "Stories of this kind usually move the odds at the margin rather than the "
    "direction of a trade, and that distinction is what separates a useful read "
    "from a reaction.\n\n"
    "That argues for treating the piece as an input to sizing and sequencing "
    "rather than as a signal to act on the day it lands. The details worth "
    "tracking are the ones that would have to be wrong for existing positioning "
    "to hurt."
)

COUNTER_NOTE = (
    "## The counter-argument\n\n"
    "Every reading of this kind has a version in which it is wrong. Here that "
    "version is simple: the data improves for a quarter, positioning normalises, "
    "and the story stops being interesting before it becomes a trend. That is "
    "worth holding alongside the more optimistic reading above, because the cost "
    "of being early and the cost of being wrong look the same in the first month."
)

WATCH_FALLBACKS = [
    "- **The next data point** - whether it confirms the direction described "
    "above or contradicts it.",
    "- **Positioning** - whether flows follow the story, or fade once the news "
    "cycle moves on.",
    "- **The counter-argument** - what would have to be true for this reading to "
    "be wrong.",
]

WATCH_TEMPLATES = [
    "- **{kw}** - whether the next print or filing confirms the direction "
    "described above, or contradicts it.",
    "- **{kw}** - the follow-through: does positioning catch up with the story, "
    "or does it fade once the news cycle moves on?",
    "- **{kw}** - the counter-argument worth testing: what would have to be "
    "true for this reading to be wrong?",
    "- **{kw}** - whether the source's next update keeps the same emphasis, or "
    "quietly shifts it.",
]


def _assemble_blog(title, lead, narrative, facts, keywords, item, brand) -> str:
    audience = brand.get("audience", "investors")
    blocks: List[str] = [f"# {title}", "", _sentence(lead), ""]

    blocks += ["## What the piece says", ""]
    for paragraph in narrative:
        blocks += [_sentence(paragraph), ""]

    if facts:
        blocks += ["## The numbers that matter", ""]
        blocks += [f"- {_sentence(fact)}" for fact in facts[:5]]
        blocks += [""]

    blocks += [
        "## Why it matters",
        "",
        f"For {audience}, the useful signal in a story like this is rarely the "
        "headline number itself. It is what the number implies about the next "
        "few quarters - whether the direction described here is a one-off print "
        "or the start of a trend that positioning has not caught up with.",
        "",
        "Read this way, the piece is best treated as a framing exercise: it "
        "tells you which variables the source is watching, which is exactly "
        "what you need before the next data point lands.",
        "",
    ]

    watch = list(keywords[:3])
    blocks += ["## What to watch", ""]
    for index, keyword in enumerate(watch):
        blocks.append(WATCH_TEMPLATES[index % len(WATCH_TEMPLATES)].format(kw=keyword))
    for line in WATCH_FALLBACKS[: max(0, 4 - len(watch))]:
        blocks.append(line)

    blocks += ["", "## Source", "", f"- {_source_line(item)}", f"- {item.get('url', '')}"]
    if item.get("paywalled"):
        blocks.append(
            "- The original is behind a paywall; this draft was built only from "
            "the publicly visible text."
        )
    if item.get("thin"):
        blocks.append(
            "- Only a short excerpt of the original was available, so this draft "
            "is thin - read the source before publishing."
        )
    blocks.append("")
    return re.sub(r"\n{3,}", "\n\n", "\n".join(blocks)).strip() + "\n"


# --------------------------------------------------------------------------- #
# files
# --------------------------------------------------------------------------- #
def to_markdown(item: Dict[str, Any], draft: Dict[str, Any]) -> str:
    header = [
        f"<!-- format: {draft['format']}",
        f"     story: {clean(item.get('title', ''))}",
        f"     source: {item.get('source_name', '')} {item.get('url', '')}",
        f"     generated: {datetime.now().strftime('%Y-%m-%d %H:%M')}",
    ]
    if draft.get("words"):
        header.append(f"     words: {draft['words']}")
    if draft.get("count"):
        header.append(f"     tweets: {draft['count']}")
    for warning in draft.get("warnings") or []:
        header.append(f"     warning: {warning}")
    header.append("-->")
    header.append("")

    if draft["format"] == "x_thread":
        body = "\n\n---\n\n".join(draft.get("tweets") or [])
    else:
        body = draft.get("text", "")
    return "\n".join(header) + body.strip() + "\n"


def slugify(text: str, limit: int = 60) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", (text or "story").lower()).strip("-")
    return (slug[:limit] or "story").rstrip("-")
