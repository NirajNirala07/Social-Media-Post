"""Remember which stories have already been turned into posts."""

from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, Iterable, Set

log = logging.getLogger(__name__)

KEEP_DAYS = 45


class State:
    def __init__(self, path: str | Path = "data/seen.json"):
        self.path = Path(path)
        self.seen: Dict[str, str] = {}
        self._load()

    def _load(self) -> None:
        if not self.path.exists():
            return
        try:
            with self.path.open("r", encoding="utf-8") as handle:
                data = json.load(handle)
            if isinstance(data, dict):
                self.seen = {str(k): str(v) for k, v in data.items()}
        except (json.JSONDecodeError, OSError) as exc:
            log.warning("could not read state file %s: %s", self.path, exc)

    def has_seen(self, url: str) -> bool:
        return url in self.seen

    def mark(self, urls: Iterable[str]) -> None:
        stamp = datetime.now(timezone.utc).isoformat(timespec="seconds")
        for url in urls:
            self.seen[url] = stamp

    def prune(self, keep_days: int = KEEP_DAYS) -> None:
        cutoff = datetime.now(timezone.utc) - timedelta(days=keep_days)
        keep: Dict[str, str] = {}
        for url, stamp in self.seen.items():
            try:
                if datetime.fromisoformat(stamp) >= cutoff:
                    keep[url] = stamp
            except ValueError:
                keep[url] = stamp
        self.seen = keep

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        with tmp.open("w", encoding="utf-8") as handle:
            json.dump(self.seen, handle, indent=1, sort_keys=True)
        tmp.replace(self.path)
        log.info("state saved with %d URLs", len(self.seen))

    def filter_new(self, urls: Iterable[str]) -> Set[str]:
        return {u for u in urls if u not in self.seen}
