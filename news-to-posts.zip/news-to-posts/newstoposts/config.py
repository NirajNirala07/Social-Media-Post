"""Configuration loading with sane defaults."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict, List

import yaml

DEFAULTS: Dict[str, Any] = {
    "run": {
        "max_age_hours": 30,
        "posts_per_day": 3,
        "min_body_chars": 700,
        "respect_robots": True,
        "fetch_delay": 1.5,
        "request_timeout": 25,
    },
    "formats": {"linkedin": True, "x_thread": True, "blog": True},
    "brand": {"name": "", "audience": "investors", "hashtags": []},
    "output": {"dir": "output", "keep_days": 60},
    "email": {"enabled": True, "skip_if_empty": True, "subject_prefix": "[Daily Brief]"},
}


def _deep_merge(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(base)
    for key, value in (override or {}).items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = _deep_merge(out[key], value)
        else:
            out[key] = value
    return out


def _read_yaml(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8") as handle:
        return yaml.safe_load(handle) or {}


class Config:
    def __init__(self, settings: Dict[str, Any], sources: List[Dict[str, Any]]):
        self.settings = _deep_merge(DEFAULTS, settings)
        self.sources = [self._normalise_source(s) for s in sources]

    @classmethod
    def load(cls, config_dir: str | os.PathLike = "config") -> "Config":
        root = Path(config_dir)
        settings = _read_yaml(root / "settings.yml")
        sources_doc = _read_yaml(root / "sources.yml")
        return cls(settings, sources_doc.get("sources", []))

    # -- convenience accessors ------------------------------------------------
    def get(self, section: str, key: str, default: Any = None) -> Any:
        return self.settings.get(section, {}).get(key, default)

    def enabled_formats(self) -> List[str]:
        formats = self.settings.get("formats", {})
        return [name for name, on in formats.items() if on]

    @staticmethod
    def _normalise_source(source: Dict[str, Any]) -> Dict[str, Any]:
        source = dict(source)
        source.setdefault("type", "rss")
        source.setdefault("weight", 1.0)
        source.setdefault("max_items", 10)
        source.setdefault("fetch_body", source["type"] == "html")
        source.setdefault("tags", [])
        source.setdefault("link_include", None)
        source.setdefault("link_exclude", None)
        if not source.get("id"):
            source["id"] = (source.get("name") or "source").lower().replace(" ", "-")
        if not source.get("name"):
            source["name"] = source["id"]
        return source


def env(name: str, default: str | None = None) -> str | None:
    value = os.environ.get(name)
    return value if value not in (None, "") else default
