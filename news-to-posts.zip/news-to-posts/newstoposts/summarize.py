"""Extractive summarisation - no API key, no model, no network.

A sentence is scored on TF-IDF over the document, with bonuses for words that
appear in the headline, for numbers (finance copy lives on figures) and for
early position. The top sentences are then put back in reading order.
"""

from __future__ import annotations

import math
import re
from collections import Counter
from typing import Dict, Iterable, List, Sequence, Tuple

STOPWORDS = set(
    """
a about above after again against all also am an and any are aren't as at be
because been before being below between both but by can can't cannot could
couldn't did didn't do does doesn't doing don't down during each few for from
further had hadn't has hasn't have haven't having he he'd he'll he's her here
here's hers herself him himself his how how's i i'd i'll i'm i've if in into is
isn't it it's its itself just let's me more most mustn't my myself no nor not
now of off on once only or other ought our ours ourselves out over own same
shan't she she'd she'll she's should shouldn't so some such than that that's the
their theirs them themselves then there there's these they they'd they'll
they're they've this those through to too under until up very was wasn't we
we'd we'll we're we've were weren't what what's when when's where where's which
while who who's whom why why's will with won't would wouldn't you you'd you'll
you're you've your yours yourself yourselves said says say according added
told noted year years month new
""".split()
)

_SENT_SPLIT = re.compile(r"(?<=[.!?])\s+(?=[A-Z0-9\"'(])")
_WORD = re.compile(r"[A-Za-z0-9][A-Za-z0-9'’\-\.%]*")


def clean(text: str) -> str:
    text = re.sub(r"<[^>]+>", " ", text or "")
    text = text.replace("\u2019", "'").replace("\u2014", " - ").replace("\u2013", "-")
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def split_sentences(text: str) -> List[str]:
    text = clean(text)
    if not text:
        return []
    raw = _SENT_SPLIT.split(text)
    out: List[str] = []
    for piece in raw:
        piece = piece.strip(" -")
        if len(piece) < 45:
            continue
        if piece.count(" ") < 6:
            continue
        if piece.lower().startswith(("read more", "sign up", "subscribe", "image")):
            continue
        out.append(piece)
    return out


def _tokens(text: str) -> List[str]:
    return [t.lower().strip(".'’-") for t in _WORD.findall(text)]


def _content_tokens(text: str) -> List[str]:
    return [t for t in _tokens(text) if t not in STOPWORDS and len(t) > 2]


def score_sentences(sentences: Sequence[str], title: str) -> List[Tuple[float, int, str]]:
    if not sentences:
        return []
    doc_freq: Counter = Counter()
    term_freqs: List[Counter] = []
    for sentence in sentences:
        counts = Counter(_content_tokens(sentence))
        term_freqs.append(counts)
        for term in counts:
            doc_freq[term] += 1

    total = len(sentences)
    title_terms = set(_content_tokens(title or ""))

    scored: List[Tuple[float, int, str]] = []
    for index, (sentence, counts) in enumerate(zip(sentences, term_freqs)):
        if not counts:
            continue
        score = 0.0
        for term, freq in counts.items():
            idf = math.log((total + 1) / (doc_freq[term] + 1)) + 1.0
            weight = 1.0
            if term in title_terms:
                weight += 0.9
            if re.search(r"\d", term):
                weight += 0.45
            if term.endswith("%"):
                weight += 0.35
            score += (1.0 + math.log(freq)) * idf * weight
        score /= math.sqrt(len(counts)) + 1.0
        score *= 1.0 + 0.4 * math.exp(-index / 6.0)
        scored.append((score, index, sentence))
    return scored


def summarize(text: str, title: str = "", max_sentences: int = 6) -> List[str]:
    sentences = split_sentences(text)
    if not sentences:
        return []
    if len(sentences) <= max_sentences:
        return sentences
    scored = score_sentences(sentences, title)
    chosen = sorted(scored, key=lambda row: row[0], reverse=True)[:max_sentences]
    return [row[2] for row in sorted(chosen, key=lambda row: row[1])]


# Words that make a phrase useless as a topic label.
GENERIC = set(
    """
    billion million trillion percent cent basis points week weeks month months year
    years quarter quarters first second third fourth last next new one two three four
    five six seven eight nine ten twenty hundred thousand according data show shows
    showed shown said says report reports analyst analysts company companies per total
    around about nearly almost more less over under since while time times number
    numbers figure figures rose rise rises fell fall falls gain gains gained lost
    record high higher low lower take takes took made make makes get gets got
    largest smallest monthly yearly annual quarterly daily weekly recent latest
    current previous fund funds monthly-total rather though however still even
    much many across within toward towards both either among biggest sharper
    sharper steady stronger weaker better worse less
    """.split()
)


def _keyset(text: str) -> set:
    return set(_content_tokens(text))


def similar(a: str, b: str, threshold: float = 0.55) -> bool:
    """True when two sentences say roughly the same thing."""
    left, right = _keyset(a), _keyset(b)
    if not left or not right:
        return False
    return len(left & right) / len(left | right) >= threshold


def key_phrases(text: str, title: str = "", limit: int = 6) -> List[str]:
    """Repeated multi-word topics, Title Cased, generic finance words removed."""
    sentences = split_sentences(text) or [clean(text)]
    title_terms = set(_content_tokens(title or ""))
    counts: Counter = Counter()
    display: Dict[str, str] = {}

    for sentence in sentences:
        words = [w for w in _content_tokens(sentence) if not re.search(r"\d", w)]
        # Two-word phrases only: they read as topics, longer ones read as
        # fragments of a sentence.
        for start in range(len(words) - 1):
            gram = words[start : start + 2]
            if len(set(gram)) < 2:
                continue
            if any(word in GENERIC for word in gram):
                continue
            # Drop verb forms - "Spreads Compressed" is not a topic label.
            if any(word.endswith(("ed", "ing")) for word in gram):
                continue
            key = " ".join(gram)
            counts[key] += 1
            display.setdefault(key, " ".join(w.capitalize() for w in gram))

    def rank(key: str) -> float:
        words = key.split()
        score = counts[key] * (1.0 + 0.5 * len(words))
        if any(word in title_terms for word in words):
            score *= 1.8
        return score

    chosen: List[str] = []
    for key, _ in sorted(counts.items(), key=lambda kv: rank(kv[0]), reverse=True):
        if counts[key] < 2:
            continue
        if any(
            word in " ".join(chosen) for word in key.split()
        ) or any(key in other for other in chosen):
            continue
        chosen.append(key)
        if len(chosen) >= limit:
            break

    return [display.get(k, k.capitalize()) for k in chosen]


def key_facts(text: str, title: str = "", limit: int = 4) -> List[str]:
    """Sentences carrying figures - these carry a finance post."""
    facts = []
    for sentence in split_sentences(text):
        digits = len(re.findall(r"\d", sentence))
        if digits >= 3 and re.search(r"(%|\$|€|₹|billion|million|bps|trillion|cr\b)", sentence, re.I):
            facts.append(sentence)
        elif digits >= 6:
            facts.append(sentence)
    if len(facts) < limit:
        for sentence in summarize(text, title, limit + 4):
            if sentence not in facts and re.search(r"\d", sentence):
                facts.append(sentence)
            if len(facts) >= limit:
                break
    return facts[:limit]


def compression_ratio(original: str, summary: Iterable[str]) -> float:
    src = len(clean(original))
    if not src:
        return 0.0
    return round(100 * sum(len(s) for s in summary) / src, 1)
