"""news-to-posts: turn a few finance sites into ready-to-publish drafts."""

__version__ = "1.0.0"
