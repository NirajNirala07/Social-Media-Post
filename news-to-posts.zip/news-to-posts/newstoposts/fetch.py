"""Fetching: HTTP transport, RSS feeds, listing pages, robots.txt."""

from __future__ import annotations

import logging
import re
import time
import urllib.robotparser as robotparser
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Dict, List, Optional
from urllib.parse import urljoin, urlparse

import feedparser
import requests
from bs4 import BeautifulSoup

log = logging.getLogger(__name__)

USER_AGENT = (
    "Mozilla/5.0 (compatible; news-to-posts/1.0; "
    "+https://github.com/; daily research digest)"
)

# Swappable so --demo can serve fixtures instead of the network.
_transport: Optional[Callable[[str, int], Optional[str]]] = None


def set_transport(fn: Optional[Callable[[str, int], Optional[str]]]) -> None:
    """Replace the network transport (used by demo mode and tests)."""
    global _transport
    _transport = fn


def _network_get(url: str, timeout: int = 25) -> Optional[str]:
    headers = {
        "User-Agent": USER_AGENT,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-IN,en;q=0.9",
    }
    for attempt in range(3):
        try:
            response = requests.get(url, headers=headers, timeout=timeout)
            if response.status_code == 200:
                response.encoding = response.apparent_encoding or response.encoding
                return response.text
            if response.status_code in (401, 403, 451):
                log.warning("blocked (%s) for %s", response.status_code, url)
                return None
            if response.status_code == 404:
                log.warning("404 for %s", url)
                return None
            log.warning("HTTP %s for %s (attempt %s)", response.status_code, url, attempt + 1)
        except requests.RequestException as exc:
            log.warning("request failed for %s: %s", url, exc)
        time.sleep(1.5 * (attempt + 1))
    return None


def http_get(url: str, timeout: int = 25) -> Optional[str]:
    if _transport is not None:
        return _transport(url, timeout)
    return _network_get(url, timeout)


# --------------------------------------------------------------------------- #
# robots.txt
# --------------------------------------------------------------------------- #
_robots_cache: Dict[str, Any] = {}


def allowed_by_robots(url: str, timeout: int = 15) -> bool:
    parsed = urlparse(url)
    if not parsed.scheme.startswith("http"):
        return False
    base = f"{parsed.scheme}://{parsed.netloc}"
    if base not in _robots_cache:
        parser = robotparser.RobotFileParser()
        parser.set_url(urljoin(base, "/robots.txt"))
        try:
            raw = http_get(urljoin(base, "/robots.txt"), timeout)
            if raw is None:
                _robots_cache[base] = None  # unknown -> do not block
            else:
                parser.parse(raw.splitlines())
                _robots_cache[base] = parser
        except Exception as exc:  # pragma: no cover - defensive
            log.debug("robots.txt unreadable for %s: %s", base, exc)
            _robots_cache[base] = None
    parser = _robots_cache[base]
    if parser is None:
        return True
    try:
        return parser.can_fetch(USER_AGENT, url)
    except Exception:  # pragma: no cover - defensive
        return True


# --------------------------------------------------------------------------- #
# Dates
# --------------------------------------------------------------------------- #
def parse_entry_date(entry: Any) -> Optional[datetime]:
    for attr in ("published_parsed", "updated_parsed", "created_parsed"):
        value = getattr(entry, attr, None) or (
            entry.get(attr) if isinstance(entry, dict) else None
        )
        if value:
            try:
                return datetime(*value[:6], tzinfo=timezone.utc)
            except (TypeError, ValueError):
                continue
    for attr in ("published", "updated", "created"):
        raw = getattr(entry, attr, None) or (
            entry.get(attr) if isinstance(entry, dict) else None
        )
        if raw:
            dt = parse_date_string(str(raw))
            if dt:
                return dt
    return None


_MONTHS = (
    "january|february|march|april|may|june|july|august|september|"
    "october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|sept|oct|nov|dec"
)

_DATE_PATTERNS = [
    (re.compile(r"(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})"), "ymd_hm"),
    (re.compile(r"(\d{4})-(\d{2})-(\d{2})"), "ymd"),
    (re.compile(rf"({_MONTHS})\.?\s+(\d{{1,2}}),?\s+(\d{{4}})", re.I), "mdy"),
    (re.compile(rf"(\d{{1,2}})\s+({_MONTHS})\.?,?\s+(\d{{4}})", re.I), "dmy"),
    (re.compile(rf"(\d{{1,2}})-({_MONTHS})-(\d{{4}})", re.I), "dmy_dash"),
]


def parse_date_string(text: str) -> Optional[datetime]:
    text = text.strip()
    month_map = {
        m: i + 1
        for i, m in enumerate(
            [
                "january", "february", "march", "april", "may", "june", "july",
                "august", "september", "october", "november", "december",
            ]
        )
    }
    for pattern, kind in _DATE_PATTERNS:
        match = pattern.search(text)
        if not match:
            continue
        try:
            if kind == "ymd_hm":
                y, mo, d, hh, mm = (int(x) for x in match.groups())
                return datetime(y, mo, d, hh, mm, tzinfo=timezone.utc)
            if kind == "ymd":
                y, mo, d = (int(x) for x in match.groups())
                return datetime(y, mo, d, tzinfo=timezone.utc)
            if kind == "mdy":
                mon, d, y = match.groups()
                return datetime(int(y), _month_number(mon, month_map), int(d), tzinfo=timezone.utc)
            if kind == "dmy":
                d, mon, y = match.groups()
                return datetime(int(y), _month_number(mon, month_map), int(d), tzinfo=timezone.utc)
            if kind == "dmy_dash":
                d, mon, y = match.groups()
                return datetime(int(y), _month_number(mon, month_map), int(d), tzinfo=timezone.utc)
        except (ValueError, KeyError):
            continue
    return None


def _month_number(token: str, month_map: Dict[str, int]) -> int:
    key = token.strip().lower().rstrip(".")
    for name, number in month_map.items():
        if name.startswith(key[:3]):
            return number
    raise KeyError(token)


# --------------------------------------------------------------------------- #
# RSS
# --------------------------------------------------------------------------- #
def _clean_text(raw: str) -> str:
    if not raw:
        return ""
    soup = BeautifulSoup(raw, "html.parser")
    text = soup.get_text(" ", strip=True)
    return re.sub(r"\s+", " ", text).strip()


def fetch_feed(source: Dict[str, Any], timeout: int = 25) -> List[Dict[str, Any]]:
    raw = http_get(source["url"], timeout)
    if not raw:
        log.warning("no content for feed %s", source["id"])
        return []
    parsed = feedparser.parse(raw)
    if parsed.bozo and not parsed.entries:
        log.warning("unparseable feed %s", source["id"])
        return []

    items: List[Dict[str, Any]] = []
    for entry in parsed.entries:
        title = _clean_text(entry.get("title", ""))
        link = entry.get("link") or ""
        if source["type"] == "google_news":
            # Google News titles look like "Headline - Bloomberg"
            title = re.sub(r"\s+-\s+[^-]{2,40}$", "", title).strip()
            link = _unwrap_google_link(link)
        if not title or not link:
            continue
        summary = ""
        for key in ("summary", "description", "content"):
            value = entry.get(key)
            if isinstance(value, list) and value:
                value = value[0].get("value", "")
            if value:
                summary = _clean_text(str(value))
                break
        items.append(
            {
                "title": title,
                "url": link,
                "summary": summary,
                "published": parse_entry_date(entry),
                "source_id": source["id"],
                "source_name": source["name"],
                "tags": list(source.get("tags") or []),
                "weight": float(source.get("weight", 1.0)),
                "body": "",
            }
        )
    log.info("feed %s -> %d items", source["id"], len(items))
    return items


def _unwrap_google_link(link: str) -> str:
    """Google News RSS links are redirectors; keep them, they still resolve."""
    return link


# --------------------------------------------------------------------------- #
# HTML listing pages
# --------------------------------------------------------------------------- #
_NAV_WORDS = {
    "read more", "learn more", "view all", "see all", "next", "previous",
    "subscribe", "sign in", "sign up", "contact us", "about us", "home",
}


def fetch_listing(source: Dict[str, Any], timeout: int = 25) -> List[Dict[str, Any]]:
    raw = http_get(source["url"], timeout)
    if not raw:
        return []
    soup = BeautifulSoup(raw, "html.parser")
    base = source["url"]
    include = source.get("link_include")
    exclude = source.get("link_exclude")

    seen = set()
    items: List[Dict[str, Any]] = []
    for anchor in soup.find_all("a", href=True):
        text = re.sub(r"\s+", " ", anchor.get_text(" ", strip=True)).strip()
        href = anchor["href"].strip()
        if not text or len(text) < 25 or len(text) > 240:
            continue
        if text.lower() in _NAV_WORDS:
            continue
        if href.startswith(("#", "mailto:", "tel:", "javascript:")):
            continue
        if include and not re.search(include, href, re.I):
            continue
        if exclude and re.search(exclude, href, re.I):
            continue
        absolute = urljoin(base, href)
        if urlparse(absolute).netloc != urlparse(base).netloc:
            continue
        if absolute in seen:
            continue
        seen.add(absolute)

        published = None
        context = anchor.find_parent(["li", "article", "div", "section"])
        if context is not None:
            published = parse_date_string(context.get_text(" ", strip=True))

        items.append(
            {
                "title": text,
                "url": absolute,
                "summary": "",
                "published": published,
                "source_id": source["id"],
                "source_name": source["name"],
                "tags": list(source.get("tags") or []),
                "weight": float(source.get("weight", 1.0)),
                "body": "",
            }
        )
        if len(items) >= int(source.get("max_items", 10)) * 3:
            break
    log.info("listing %s -> %d candidate links", source["id"], len(items))
    return items


def collect(source: Dict[str, Any], timeout: int = 25) -> List[Dict[str, Any]]:
    kind = source.get("type", "rss")
    if kind in ("rss", "google_news"):
        return fetch_feed(source, timeout)
    if kind == "html":
        return fetch_listing(source, timeout)
    log.error("unknown source type %r for %s", kind, source.get("id"))
    return []


def within_age(published: Optional[datetime], max_age_hours: float) -> bool:
    if published is None:
        return True  # undated items are allowed through, ranked lower later
    cutoff = datetime.now(timezone.utc) - timedelta(hours=max_age_hours)
    return published >= cutoff
