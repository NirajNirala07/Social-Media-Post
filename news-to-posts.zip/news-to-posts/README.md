# news-to-posts

Watches a handful of finance sites every morning, picks the strongest stories,
and turns each one into three publish-ready drafts:

- a **LinkedIn post** (150–250 words)
- an **X thread** (5–7 tweets, each under 280 characters)
- a **blog article** (600–900 words)

Everything lands in your inbox as one HTML email, and the same drafts are saved
as Markdown files you can copy-paste from.

No API keys, no paid model, no server. It runs on GitHub Actions for free.

---

## How it works

```
config/sources.yml
      │
      ├── RSS feed ──────────┐
      ├── Google News RSS ───┤
      └── listing page ──────┤   (fetch.py)
                             ▼
                    article body extraction   (extract.py)
                             ▼
              dedupe → score → pick top 3      (run.py)
                             ▼
        extractive summary + key facts         (summarize.py)
                             ▼
        LinkedIn · X thread · blog drafts      (posts.py)
                             ▼
          Markdown files + HTML email          (digest.py)
```

Summarising is **extractive**: it scores the sentences that already exist in the
source (TF-IDF, headline overlap, numbers, early position) and keeps the best
ones in reading order. It does not invent sentences, and it does not need a
language model. That is the trade-off: the drafts are accurate and fast, but the
prose is the source's prose rearranged, with claim-free framing around it. Read
every draft before you publish it.

---

## Quick start (2 minutes, no setup)

```bash
pip install -r requirements.txt
python run.py --demo --no-email
```

`--demo` runs the whole pipeline on bundled sample files in `fixtures/` instead
of the live sites, so you can see the output without any credentials. Open
`output/<today>/digest.md` or the individual files under `linkedin/`, `x_thread/`
and `blog/`.

The sample files are synthetic — they are not real Bloomberg or Morgan Stanley
content, and the demo output must not be published.

## A real run, locally

```bash
python run.py --limit 2 --no-email      # draft 2 stories, skip the email
python run.py                           # draft 3 stories and email them
```

Useful flags:

| Flag | What it does |
|---|---|
| `--demo` | run on `fixtures/`, no network |
| `--no-email` | write files only |
| `--limit N` | how many stories to draft today |
| `--formats linkedin blog` | only these formats |
| `--ignore-state` | re-draft stories already used before |
| `-v` | verbose logging |

---

## Put it on a daily schedule (GitHub Actions)

1. **Create a repository** on GitHub and push this folder to it.

   ```bash
   cd news-to-posts
   git init && git add . && git commit -m "news-to-posts"
   git branch -M main
   git remote add origin https://github.com/<you>/news-to-posts.git
   git push -u origin main
   ```

2. **Add your email credentials** under *Settings → Secrets and variables →
   Actions → New repository secret*:

   | Secret | Value |
   |---|---|
   | `SMTP_USER` | the account the email is sent **from**, e.g. `nirajnirala07@gmail.com` |
   | `SMTP_PASSWORD` | an **app password** (not your normal password) |
   | `MAIL_TO` | optional — the digest already goes to `nirajnirala07@gmail.com` from `config/settings.yml`; set this only to send somewhere else |
   | `SMTP_HOST` | optional, defaults to `smtp.gmail.com` |
   | `SMTP_PORT` | optional, defaults to `587` |

   For Gmail: turn on 2-Step Verification, then go to
   *Google Account → Security → App passwords*, create one for "Mail", and paste
   the 16-character value as `SMTP_PASSWORD`. Your normal password will not work.

   Using a different provider? Any SMTP service works — Zoho, Outlook,
   Fastmail, Amazon SES, Resend SMTP. Use its host and port.

3. **Check the schedule.** `.github/workflows/daily.yml` runs at `02:30 UTC`
   (08:00 IST). Edit the `cron` line to change it, or run it immediately from
   the Actions tab with *Run workflow*.

4. Every run emails you the digest and saves the drafts as a downloadable
   artifact on the run page. `data/seen.json` is committed back so a story is
   never drafted twice.

---

## Configuration

### `config/sources.yml` — where the material comes from

Three source types:

```yaml
- id: bloomberg-markets
  name: Bloomberg Markets
  type: rss                      # a normal RSS/Atom feed
  url: https://feeds.bloomberg.com/markets/news.rss
  weight: 1.3                    # higher = wins ties when picking the top 3
  max_items: 10
  fetch_body: true               # also fetch the article text
  tags: [markets]

- id: bloomberg-india
  name: Bloomberg on India
  type: google_news              # Google News RSS search
  url: https://news.google.com/rss/search?q=site:bloomberg.com+India+when:2d&hl=en-IN&gl=IN&ceid=IN:en

- id: ms-insights
  name: Morgan Stanley Ideas
  type: html                     # parse a public listing page for article links
  url: https://www.morganstanley.com/insights
  link_include: '(/articles/|/ideas/|/insights/)'   # only these links count
  link_exclude: '(#|mailto:|/newsletter/)'
```

Add any site by copying a block. For a site with an RSS feed, use `type: rss`.
For a site without one, use `type: html` and tune `link_include` so only real
article links are picked up.

**Shipped sources:** Bloomberg top news, markets and economics feeds; Bloomberg
India coverage via Google News; Morgan Stanley Ideas and Newsroom listing pages;
Morgan Stanley via Google News.

Morgan Stanley does not publish an RSS feed, so its two listing pages are parsed
for article links. Bloomberg does publish RSS — that is the intended way to read
it. The tool does not scrape Bloomberg's paywalled article pages; where a page
is blocked or behind the paywall, the draft is built from the feed summary and
marked as thin.

### `config/settings.yml` — how the run behaves

```yaml
run:
  max_age_hours: 30      # ignore older stories
  posts_per_day: 3       # how many stories become drafts
  min_body_chars: 700    # below this a story is flagged as thin
  respect_robots: true   # obey robots.txt before fetching an article body
  fetch_delay: 1.5       # seconds between article fetches

brand:
  audience: "investors and finance professionals in India"
  hashtags: ["#Markets", "#Investing", "#Bloomberg", "#MorganStanley"]
```

`brand.audience` is woven into the "why it matters" line of every draft, and
`brand.hashtags` close the LinkedIn post and the X thread.

The digest recipient is set in the same file:

```yaml
email:
  enabled: true
  to: "nirajnirala07@gmail.com"
  subject_prefix: "[Daily Brief]"
```

`email.to` is where every run emails the drafts. The `MAIL_TO` secret, if you
set one, takes precedence — handy for pointing a test run at a different inbox.

---

## Output

```
output/2026-11-17/
├── digest.html          # the email, standalone
├── digest.md            # same content, Markdown
├── linkedin/01-<slug>.md
├── x_thread/01-<slug>.md
└── blog/01-<slug>.md
```

Each Markdown file opens with an HTML comment carrying the source URL, word or
tweet count, and any warnings. The comment is invisible in every Markdown
editor, so you can copy the text straight into LinkedIn, X or your blog.

Warnings you will see and what they mean:

| Warning | Meaning |
|---|---|
| `built from a short source excerpt` | the article body was paywalled or blocked; only the feed summary was available |
| `short: N words` | the source did not contain enough text to reach the target length |
| `only N tweets` | same, for the thread |
| `N tweet(s) over 280 characters` | a single source sentence was longer than a tweet |

Folders older than `output.keep_days` are deleted automatically.

---

## Tests

```bash
python tests/test_pipeline.py        # no pytest needed
python -m pytest -q                  # or with pytest
```

15 tests cover body extraction, paywall detection, summary ordering, duplicate
detection, word/tweet length limits, and config loading. They run in CI before
every scheduled run, so a broken parser fails loudly instead of emailing you
garbage.

---

## Honest limits

- **These are drafts, not finished copy.** The prose is the source's own
  sentences, reordered and framed. It reads cleanly but it is not original
  analysis, and it will not sound like you until you edit it. Budget five
  minutes per story.
- **Bloomberg is paywalled.** Its terms of service do not allow scraping
  articles. The tool reads Bloomberg's public RSS feeds (headline, summary,
  link), obeys `robots.txt`, and never bypasses a paywall. Stories where only a
  summary was available are flagged, so you know which drafts need you to read
  the original first.
- **Copyright.** Reproducing large parts of someone else's article verbatim is
  not yours to publish. Use these drafts as the basis for your own post — the
  extractive summary is a reading aid, and the framing around it is what you
  make your own.
- **No sentiment, no prediction.** The tool cannot tell you whether a story is
  bullish or bearish, and it does not try. It summarises what the source said.
- **Feeds change.** A source can rename its feed URL or change its HTML and the
  run will quietly return fewer stories. The log line `feed <id> -> 0 items` is
  the signal to check `sources.yml`.
- **Nothing here is investment advice.** It is a reading and drafting tool.

## Extending it

- **A new site with RSS** — one block in `sources.yml`, done.
- **A site without RSS** — `type: html` plus a `link_include` regex.
- **Different post formats** — add a `build_<format>()` function in
  `newstoposts/posts.py` and turn it on under `formats:` in `settings.yml`.
- **Better prose** — set `SMTP_*` aside and plug a model into
  `newstoposts/posts.py`: replace `_assemble_blog` with a call to your provider,
  passing `item["sentences"]` as the evidence. The extraction and scoring layers
  stay as they are.
- **Slack or a Google Doc instead of email** — `newstoposts/digest.py` builds
  the HTML and Markdown; send it wherever you like.
